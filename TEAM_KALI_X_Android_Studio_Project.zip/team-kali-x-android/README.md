# TEAM KALI X Android WebView app

This Android Studio project wraps `https://pakpro.store/team-kali.php` in a native Android WebView.

## Build an APK

1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install any requested Android build tools.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

For a release APK, use **Build > Generate Signed Bundle / APK** and create or select your own signing key.

## App details

- App label: TEAM KALI X
- Package: `com.pakpro.teamkalix`
- Minimum Android: 6.0 (API 23)
- Website: `https://pakpro.store/team-kali.php`

The app loads the website live; it does not copy the site's backend or make it work offline. Website availability, login, and server-side behavior remain controlled by the website. The app does not collect or transmit credentials separately from the website.
